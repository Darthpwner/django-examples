from django.views import generic
from rest_framework import viewsets

from django_server import models
from django_server import serializers


class SummaryView(generic.DetailView):
    model = models.Summary

summary_view = SummaryView.as_view()

class SummarySetView(viewsets.ReadOnlyModelViewSet):
    queryset = models.Summary.objects.all()
    serializer_class = serializers.SummarySerializer

