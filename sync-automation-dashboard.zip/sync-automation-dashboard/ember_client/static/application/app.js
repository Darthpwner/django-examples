window.Dashboard = Ember.Application.create();

