Django + Django REST Framework + Ember.js example application
================================================================

This is an example application. Install dependencies from requiremenents.txt and start the development server.
